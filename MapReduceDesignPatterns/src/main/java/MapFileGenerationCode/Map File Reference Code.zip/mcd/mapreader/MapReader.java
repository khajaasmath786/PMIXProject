package mapreader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.MapFile;
import org.apache.hadoop.io.MapFile.Reader;
import java.net.URI;
import java.io.*;
import org.apache.hadoop.util.ReflectionUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class MapReader {
	public static void main(String[] args) throws IOException {
		String mapUri = args[0];
		Configuration conf = new Configuration();
		conf.set("dfs.support.broken.append","True");
		
		FileSystem fs = FileSystem.get(URI.create(mapUri), conf);
		//Path map = new Path(mapUri);
		//String mapData = new Path(map, MapFile.DATA_FILE_NAME);
		// Get key and value types from data sequence file
		MapFile.Reader reader = new MapFile.Reader(fs, mapUri, conf);
		Text value = new Text();
			
		//Text key = (Text)
		ReflectionUtils.newInstance(reader.getKeyClass(), conf);
		//Text value = (Text)
		ReflectionUtils.newInstance(reader.getValueClass(), conf);
		
		reader.get(new Text(args[1]), value);
		//reader.next(new Text(args[1]), value);
		//reader.hashCode()
				
		System.out.println("test"+conf.get("dfs.support.broken.append"));
		
		System.out.println("append allowed : "+conf.get("dfs.support.append"));
		
		System.out.println("value is : "+value.toString());
		
		//while (reader.next(new Text(args[1]), value)) {
		//	reader.finalKey(arg0)
		//	System.out.println("value is : "+value.toString());
		//	}
		reader.close();
		}
	}