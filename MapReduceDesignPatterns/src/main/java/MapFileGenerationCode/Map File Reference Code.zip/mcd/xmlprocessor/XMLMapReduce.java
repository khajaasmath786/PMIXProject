package iv3.xmlprocessor;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.hbase.client.Put;
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
//import org.apache.hadoop.hbase.mapreduce.TableMapReduceUtil;
//import org.apache.hadoop.hbase.mapreduce.TableReducer;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.*;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class XMLMapReduce {

                public static class Map extends Mapper<LongWritable, Text, Text, Text> {

                                Text emitKey = new Text();
                                Text emitValue = new Text();
                                String fileDate="some value";
                                
                                @Override
                                public void setup(Context context) 

                                {

                                Configuration conf = context.getConfiguration();

                                fileDate = conf.get("FileDate");

                                
                                }


                                
                                @Override
    protected void map(LongWritable key, Text value,Context context)throws IOException, 
    InterruptedException {
                                                
      String document = value.toString();
      
      //Debug --- System.out.println("'" + document + "'");
     
                
      
        String propertyName = "Key";
        String propertyValue = "";
//        List<String> propertyValue = new ArrayList<String>();
        
        try {
                
                 DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
             InputSource is = new InputSource();
             is.setCharacterStream(new StringReader(document));
             Document doc = db.parse(is);
//             NodeList nl1;
             
//             if(doc.hasChildNodes()){//if starts
//           
//                            nl1=doc.getChildNodes();
//                            Node n1 = doc.getFirstChild();
//                            for(int i=0; i<nl1.getLength();i++){
//                            
//                                            
//                                    
//                  //child one end                       
//                 Node tmp = n1.getNextSibling();
//                 n1 = tmp;
//                            }
//             }//if ends
             
                                
             Node n = doc.getFirstChild();

                
             if (n.hasAttributes()) {//if starts
               NamedNodeMap nodeMap = n.getAttributes();                               
               for (int index = 0; index < nodeMap.getLength(); index++) {                        
                    Node node = nodeMap.item(index);
                    if(node.getNodeName()=="id"){
                                propertyValue=node.getNodeValue();   
                     }else{
                        propertyValue=propertyValue+"\t"+node.getNodeValue();
                     }
                                  
//                            }
                }//if ends
//                            n = nextChild;
             
             emitKey.set(propertyName.trim());
             emitValue.set(propertyValue.trim());
          
             context.write(emitKey,emitValue);
             }
       }catch(Exception e){
                  e.printStackTrace();
      }//try-catch block ends here
                }//map method ends
}//mapper class ends
            /*
             *     
            
   public static class MyReducer extends TableReducer<Text, Text, ImmutableBytesWritable>
   {
  public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
   {
   Put data = null;
    for(Text value: values)
         {
             String[] parts = value.toString().split("\\t");
                    if(parts.length == 3)
                             {
                                       String myRow = parts[0]; //+ ":" + parts[2];
                                       data = new Put(myRow.getBytes());
                                    data.add("ProductData".getBytes(), "familyGroup".getBytes(), parts[1].getBytes());
                                         data.add("ProductData".getBytes(), "ProductName".getBytes(), parts[2].getBytes());
                            context.write(null, data);
              }
                                context.write(null,data);
         }
        }
      }
                
              */
                public static void main(String... args) throws Exception {
                                if (args.length < 2) {
                                                System.out.println(" ");
                                                System.out
                                                                                .println("*****************************************************************");
                                                System.out
                                                                                .println("The program requires minimum three input parameters");
                                                System.out
                                                                                .println("---------------------Input format Help---------------------------");
                                                System.out.println("Input 1 : -I='Input file'");
                                                System.out.println("Input 2 : -O='Output path'");
                                                System.out
                                                                                .println("-----------------------------------------------------------------");
                                                System.out.println(" ");
                                                System.exit(1);
                                }

                                else if (!args[0].startsWith("-I=") | !args[1].startsWith("-O=")) {
                                                System.out.println(" ");
                                                System.out
                                                                                .println("*****************************************************************");
                                                System.out
                                                                                .println("The program requires minimum three input parameters");
                                                System.out
                                                                                .println("---------------------Input format Help---------------------------");
                                                System.out.println("Input 1 : -I='Input file'");
                                                System.out.println("Input 2 : -O='Output path'");
                                                System.out
                                                                                .println("-----------------------------------------------------------------");
                                                System.out.println(" ");
                                } else {
                                                runJob(args[0].substring(4, args[0].length()), args[1].substring(4,
                                                                                args[1].length()));
                                }

                }

          
                public static void runJob(String input, String output) throws Exception {
                                Configuration conf = new Configuration();
                                conf.set("key.value.separator.in.input.line", " ");
                                conf.set("xmlinput.start", "<ProductInfo");
                                conf.set("xmlinput.end", "/>");

                                Job job = new Job(conf);
                                job.setJarByClass(XMLMapReduce.class);

                                job.setMapperClass(Map.class);
                                
                             //   TableMapReduceUtil.initTableReducerJob("mcd_ProductData", MyReducer.class, job);
                                
                                job.setMapOutputKeyClass(Text.class);
                                job.setMapOutputValueClass(Text.class);
                                
                                job.setOutputKeyClass(Text.class);
                                job.setOutputValueClass(Text.class);

                                
                                job.setInputFormatClass(XmlInputFormat.class);
                                job.setOutputFormatClass(TextOutputFormat.class);
                                
                                
//                            job.setNumReduceTasks(0);
//                            conf.set("FileDate", getDate(input));
                                getDate(input);
                                FileInputFormat.setInputPaths(job, new Path(input));
                                Path outPath = new Path(output);
                                FileOutputFormat.setOutputPath(job, outPath);
                                outPath.getFileSystem(conf).delete(outPath, true);

                                System.exit(job.waitForCompletion(true) ? 0 : 1);
                }
                
                public static String getDate(String fileName){
                                
                                String filedate="";
                                String regex = "(^.*_(\\d{8})).(.*)";
                                Pattern pattern = Pattern.compile(regex);
                                Matcher matcher = null;
                                matcher = pattern.matcher(fileName);
                                if(matcher.find()){
                                                filedate = matcher.group(2);
                                                
                                }
                                
                                return filedate;
                }
}

